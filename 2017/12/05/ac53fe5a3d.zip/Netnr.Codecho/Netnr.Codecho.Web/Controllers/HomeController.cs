﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Netnr.Codecho.Web.EFCore;
using System.Data;
using System.Collections;

namespace Netnr.Codecho.Web.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Config()
        {
            string ConfigGroup = RouteData.Values["id"]?.ToString();

            return View();
        }

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Test()
        {
            string result = string.Empty;

            var runtime = new List<TimeSpan>();
            Stopwatch sw = new Stopwatch();
            sw.Start();

            switch (Request.Query["cache"])
            {
                case "1":
                    {
                        var dics = new Dictionary<string, Dictionary<string, object>>();
                        for (int i = 0; i < 999999; i++)
                        {
                            var dic = new Dictionary<string, object>();

                            string key = i.ToString();

                            dic.Add("col_0", key);
                            dic.Add("col_1", key + key);
                            dic.Add("col_2", key + key + key);
                            dic.Add("col_3", key + key + key + key);

                            dics.Add(key, dic);
                        }

                        var search = dics.Where(x => new List<string> { "32898", "4563", "12", "894561", "99999" }.Contains(x.Key));
                    }
                    break;
            }

            runtime.Add(sw.Elapsed);

            result = runtime.ToJson();

            return Content(result);
        }
    }
}
