﻿using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Netnr.Codecho.Web.Models;
using System;
using System.Linq;
using System.Reflection;

namespace Netnr.Codecho.Web.EFCore
{
    public class ContextBase : DbContext
    {
        public ContextBase() : base()
        { }

        public DbSet<NC_Config> NC_Config { get; set; }
        public DbSet<NC_Convert> NC_Convert { get; set; }
        public DbSet<NC_DbType> NC_DbType { get; set; }
        public DbSet<NC_PlatformType> NC_PlatformType { get; set; }
        public DbSet<NC_Template> NC_Template { get; set; }

        /// <summary>
        /// 映射
        /// </summary>
        /// <param name="builder"></param>
        protected override void OnModelCreating(ModelBuilder builder)
        {
            //builder.Entity<Platform_Type>().ToTable("Platform_Type");
            //builder.Entity<Platform_Type>().HasKey(m => m.Id);

            base.OnModelCreating(builder);
        }

        /// <summary>
        /// 配置
        /// </summary>
        /// <param name="optionsBuilder"></param>
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            var connectionStringBuilder = new SqliteConnectionStringBuilder()
            {
                DataSource = AppDomain.CurrentDomain.BaseDirectory
                            .Replace(AppDomain.CurrentDomain.FriendlyName, "^")
                            .Split('^')[0] + AppDomain.CurrentDomain.FriendlyName + "\\Data\\sqlite.db"
            };
            var connection = new SqliteConnection(connectionStringBuilder.ConnectionString);
            optionsBuilder.UseSqlite(connection);
        }
    }
}
