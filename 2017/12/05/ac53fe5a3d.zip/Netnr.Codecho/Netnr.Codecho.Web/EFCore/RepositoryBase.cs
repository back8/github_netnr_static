﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Linq.Expressions;
using System.Linq.Dynamic.Core;

namespace Netnr.Codecho.Web.EFCore
{
    /// <summary>
    /// 实现泛型接口
    /// </summary>
    /// <typeparam name="TEntity"></typeparam>
    public class RepositoryBase<TEntity> : IRepositoryBase<TEntity> where TEntity : class, new()
    {
        internal ContextBase context;
        internal DbSet<TEntity> dbSet;

        public RepositoryBase(ContextBase _context)
        {
            context = _context;
            dbSet = context.Set<TEntity>();
        }


        public int Insert(TEntity entity, bool isSave = true)
        {
            dbSet.Add(entity);
            return isSave ? context.SaveChanges() : 0;
        }
        public int Insert(List<TEntity> entitys, bool isSave = true)
        {
            dbSet.AddRange(entitys);
            return isSave ? context.SaveChanges() : 0;
        }


        public int Update(TEntity entity, bool isSave = true)
        {
            dbSet.Update(entity);
            return isSave ? context.SaveChanges() : 0;
        }


        public int Delete(TEntity entity, bool isSave = true)
        {
            dbSet.Remove(entity);
            return isSave ? context.SaveChanges() : 0;
        }
        public int Delete(Expression<Func<TEntity, bool>> predicate, bool isSave = true)
        {
            dbSet.RemoveRange(dbSet.Where(predicate));
            return isSave ? context.SaveChanges() : 0;
        }


        public TEntity FindEntity(object keyValue)
        {
            return dbSet.Find(keyValue);
        }
        public TEntity FindEntity(Expression<Func<TEntity, bool>> predicate)
        {
            return dbSet.FirstOrDefault(predicate);
        }


        public IQueryable<TEntity> IQueryable()
        {
            return dbSet;
        }
        public IQueryable<TEntity> IQueryable(Expression<Func<TEntity, bool>> predicate)
        {
            return dbSet.Where(predicate);
        }


        public List<TEntity> FindList(Expression<Func<TEntity, bool>> pWhere, Paging paging)
        {
            var query = dbSet.AsNoTracking().Where(pWhere);

            paging.CountAll = query.Count();

            List<string> listField = paging.SortFields.Split(',').ToList();
            List<string> listSort = paging.SortModes.Split(',').ToList();

            string OrderBys = string.Empty;
            for (int i = 0; i < listField.Count; i++)
            {
                string sortF = listField[i].Replace("'", "''").Trim();
                string sortM = listSort[i].ToLower() == "asc" ? "asc" : "desc";
                OrderBys += "," + sortF + " " + sortM;
            }
            
            query = DynamicQueryableExtensions.OrderBy(query, OrderBys.TrimStart(','));

            query = query.Skip((paging.PageIndex - 1) * paging.PageSize).Take(paging.PageSize);

            return query.ToList();
        }
    }
}
