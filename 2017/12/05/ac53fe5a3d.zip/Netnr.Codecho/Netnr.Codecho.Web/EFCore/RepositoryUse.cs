﻿using Netnr.Codecho.Web.Models;
using System;

namespace Netnr.Codecho.Web.EFCore
{
    /// <summary>
    /// 统一入口，保证上下文（context）的一致性
    /// 如果不想手动释放资源，请用using
    /// </summary>
    public class RepositoryUse : IDisposable
    {
        #region Save & Dispose
        public int Save()
        {
            return context.SaveChanges();
        }

        private bool disposed = false;
        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    context.Dispose();
                }
            }
            disposed = true;
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        #endregion

        /// <summary>
        /// 上下文
        /// </summary>
        public ContextBase context
        {
            get
            {
                return new ContextBase();
            }
        }

        #region 单表仓库
        private RepositoryBase<NC_PlatformType> nc_platformtypeRepository;

        public RepositoryBase<NC_PlatformType> NC_PlatformTypeRepository
        {
            get
            {
                if (nc_platformtypeRepository == null)
                {
                    nc_platformtypeRepository = new RepositoryBase<NC_PlatformType>(context);
                }
                return nc_platformtypeRepository;
            }
        }
        #endregion

    }
}
