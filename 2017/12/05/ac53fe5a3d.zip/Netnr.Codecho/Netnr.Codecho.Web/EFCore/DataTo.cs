﻿using System;
using Microsoft.AspNetCore.Hosting;

namespace Netnr.Codecho.Web
{
    #region Common
    
    /// <summary>
    /// 分页参数
    /// </summary>
    public class Paging
    {
        /// <summary>
        /// 页码
        /// </summary>
        public int PageIndex { get; set; }
        /// <summary>
        /// 页量
        /// </summary>
        public int PageSize { get; set; }
        /// <summary>
        /// 总数量
        /// </summary>
        public int CountAll { get; set; }
        /// <summary>
        /// 排序字段，英文逗号分隔
        /// </summary>
        public string SortFields { get; set; }
        /// <summary>
        /// 排序类型，英文逗号分隔
        /// </summary>
        public string SortModes { get; set; }
        /// <summary>
        /// 总页数
        /// </summary>
        public int PageTotal
        {
            get
            {
                int pt = 0;
                try
                {
                    pt = Convert.ToInt32(Math.Ceiling(Convert.ToDecimal(CountAll / PageSize)));
                }
                catch (Exception)
                {
                }
                return pt;
            }
        }
    }

    #endregion
}
