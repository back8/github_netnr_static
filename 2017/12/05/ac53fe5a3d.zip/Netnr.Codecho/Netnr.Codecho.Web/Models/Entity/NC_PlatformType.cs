﻿using System;
namespace  Netnr.Codecho.Web.Models
{
	/// <summary>
	/// NC_PlatformType:实体类(属性说明自动提取数据库字段的描述信息)
	/// </summary>
	[Serializable]
	public partial class NC_PlatformType
	{
		public NC_PlatformType()
		{}
        #region Model
        private string _id;
        private string _ptname;
        /// <summary>
        /// 
        /// </summary>
        public string Id
        {
            set { _id = value; }
            get { return _id; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string PtName
		{
			set{ _ptname=value;}
			get{return _ptname;}
		}
		#endregion Model

	}
}

