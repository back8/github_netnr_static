﻿using System;
namespace  Netnr.Codecho.Web.Models
{
	/// <summary>
	/// NC_Convert:实体类(属性说明自动提取数据库字段的描述信息)
	/// </summary>
	[Serializable]
	public partial class NC_Convert
	{
		public NC_Convert()
		{}
        #region Model
        private string _id;
        private string _convertgroup;
		private string _convertbegin;
		private string _convertend;
        /// <summary>
        /// 
        /// </summary>
        public string Id
        {
            set { _id = value; }
            get { return _id; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string ConvertGroup
		{
			set{ _convertgroup=value;}
			get{return _convertgroup;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string ConvertBegin
		{
			set{ _convertbegin=value;}
			get{return _convertbegin;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string ConvertEnd
		{
			set{ _convertend=value;}
			get{return _convertend;}
		}
		#endregion Model

	}
}

