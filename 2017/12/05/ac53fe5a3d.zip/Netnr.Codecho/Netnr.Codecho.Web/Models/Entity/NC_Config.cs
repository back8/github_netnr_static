﻿using System;
namespace  Netnr.Codecho.Web.Models
{
	/// <summary>
	/// NC_Config:实体类(属性说明自动提取数据库字段的描述信息)
	/// </summary>
	[Serializable]
	public partial class NC_Config
	{
		public NC_Config()
		{}
		#region Model
		private string _id;
		private string _configgroup;
		private string _configkey;
		private string _configvalue;
		private string _remark;
		/// <summary>
		/// 
		/// </summary>
		public string Id
		{
			set{ _id = value;}
			get{return _id; }
		}
		/// <summary>
		/// 
		/// </summary>
		public string ConfigGroup
		{
			set{ _configgroup=value;}
			get{return _configgroup;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string ConfigKey
		{
			set{ _configkey=value;}
			get{return _configkey;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string ConfigValue
		{
			set{ _configvalue=value;}
			get{return _configvalue;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string Remark
		{
			set{ _remark=value;}
			get{return _remark;}
		}
		#endregion Model

	}
}

