﻿using System;
namespace  Netnr.Codecho.Web.Models
{
	/// <summary>
	/// NC_Template:实体类(属性说明自动提取数据库字段的描述信息)
	/// </summary>
	[Serializable]
	public partial class NC_Template
	{
		public NC_Template()
		{}
        #region Model
        private string _id;
        private string _templatename;
		private string _templatecontent;
		private string _templatethe;
        /// <summary>
        /// 
        /// </summary>
        public string Id
        {
            set { _id = value; }
            get { return _id; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string TemplateName
		{
			set{ _templatename=value;}
			get{return _templatename;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string TemplateContent
		{
			set{ _templatecontent=value;}
			get{return _templatecontent;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string TemplateThe
		{
			set{ _templatethe=value;}
			get{return _templatethe;}
		}
		#endregion Model

	}
}

