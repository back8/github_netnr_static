﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Netnr.Codecho.Web.Models
{
    public class Config
    {
        public class ConfigGroupKey
        {
            /// <summary>
            /// 连接
            /// </summary>
            public const string Connect = "1";
            /// <summary>
            /// 命名规则
            /// </summary>
            public const string NamingRules = "2";
        }

        public class ConvertGroupKey
        {
            public const string SqlDbType = "1";
            public const string DbType = "2";
            public const string OleDbType = "3";
            public const string OracleType = "4";
            public const string MySqlDbType = "5";

            /// <summary>
            /// 类型允许为空
            /// </summary>
            public const string AllowForEmpty = "6";
            /// <summary>
            /// 数据库类型 转 类
            /// </summary>
            public const string DbForClass = "7";
        }
    }
}
